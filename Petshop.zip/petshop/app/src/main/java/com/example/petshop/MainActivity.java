package com.example.petshop;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    Button bLogin, bCadastro;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_main);
        bLogin = findViewById(R.id.bLogin);
        bCadastro = findViewById(R.id.bCadastro);
    }

    public void logar(View v) {
        startActivity(new Intent(getApplicationContext(), telaLogin.class));
    }

    public void cadastrar(View v) {
        startActivity(new Intent(getApplicationContext(), telaCadastro.class));
    }
}